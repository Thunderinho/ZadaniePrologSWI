character(arrow).
character(steve).
character(romanov).

weapons(gun).
weapons(bow).
weapons(shield).

female(romanov).
male(steve; arrow).

holdsAWeapon(steve, shield).
holdsAWeapon(arrow, bow).
holdsAWeapon(romanov, gun).
