character(chandler).
character(rachel).
character(ross).
character(monica).
character(joey).
character(phoebe).

loves(rachel, ross).
loves(rachel, joey).
loves(monica, chandler).
loves(ross, rachel).
loves(joey, rachel).
loves(chandler, monica).

eatLeftDessert(chandler; rachel; ross).
eatRightDessert(monica; joey; phoebe).
